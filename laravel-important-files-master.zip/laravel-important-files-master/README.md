# laravel-important-files
Some important functions and files for Laravel Projects
