Laravel\Socialite\Two\User Object
(
    [token] => e94052ee620387b3b8835f48be2697129d140843
    [refreshToken] => 
    [expiresIn] => 
    [id] => 14022699
    [nickname] => hosainshohan1
    [name] => Md. Shohan Hossain
    [email] => hossain_shohan1@live.com
    [avatar] => https://avatars1.githubusercontent.com/u/14022699?v=4
    [user] => Array
        (
            [login] => hosainshohan1
            [id] => 14022699
            [avatar_url] => https://avatars1.githubusercontent.com/u/14022699?v=4
            [gravatar_id] => 
            [url] => https://api.github.com/users/hosainshohan1
            [html_url] => https://github.com/hosainshohan1
            [followers_url] => https://api.github.com/users/hosainshohan1/followers
            [following_url] => https://api.github.com/users/hosainshohan1/following{/other_user}
            [gists_url] => https://api.github.com/users/hosainshohan1/gists{/gist_id}
            [starred_url] => https://api.github.com/users/hosainshohan1/starred{/owner}{/repo}
            [subscriptions_url] => https://api.github.com/users/hosainshohan1/subscriptions
            [organizations_url] => https://api.github.com/users/hosainshohan1/orgs
            [repos_url] => https://api.github.com/users/hosainshohan1/repos
            [events_url] => https://api.github.com/users/hosainshohan1/events{/privacy}
            [received_events_url] => https://api.github.com/users/hosainshohan1/received_events
            [type] => User
            [site_admin] => 
            [name] => Md. Shohan Hossain
            [company] => @vencerlab 
            [blog] => www.shohans.com
            [location] => Dhaka, Bangladesh
            [email] => hossain_shohan1@live.com
            [hireable] => 1
            [bio] => Always a learner.
Trying to build something new with @vencerlab 
            [public_repos] => 9
            [public_gists] => 0
            [followers] => 2
            [following] => 7
            [created_at] => 2015-08-28T22:08:43Z
            [updated_at] => 2017-12-10T10:29:49Z
        )

)