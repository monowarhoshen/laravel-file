Laravel\Socialite\Two\User Object
(
    [token] => EAAH6XLcG3RIBAGz6B8cPe8D5Pvkrg3ltcsotfTnD5FcretsgvYsHBApqhQ97x5sZCSe4hnOpZAMj9psyqdU1XZCvwsAqlu2iclAEZAxOcx2cy2OtXZBO5zjT66yIPmYNLZAUK1ZCYh79apb1FaxO2PZBZCZCcvNdYtFI7HxZBjUTAFt7gZDZD
    [refreshToken] => 
    [expiresIn] => 5184000
    [id] => 2023092997979179
    [nickname] => 
    [name] => Shohan Hossain
    [email] => shohanh1@gmail.com
    [avatar] => https://graph.facebook.com/v2.10/2023092997979179/picture?type=normal
    [user] => Array
        (
            [name] => Shohan Hossain
            [email] => shohanh1@gmail.com
            [gender] => male
            [verified] => 1
            [link] => https://www.facebook.com/app_scoped_user_id/2023092997979179/
            [id] => 2023092997979179
        )

    [avatar_original] => https://graph.facebook.com/v2.10/2023092997979179/picture?width=1920
    [profileUrl] => https://www.facebook.com/app_scoped_user_id/2023092997979179/
)