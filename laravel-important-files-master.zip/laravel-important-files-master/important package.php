#image upload to directorty
http://image.intervention.io/

#laravel charts
https://erik.cat/projects/charts

#pdf download
https://github.com/barryvdh/laravel-dompdf

#permission package
https://github.com/spatie/laravel-permission

#live chat with pusher(didn't work at first try)
https://blog.pusher.com/how-to-build-a-laravel-chat-app-with-pusher/

#breadcrumbs generator
https://github.com/davejamesmiller/laravel-breadcrumbs

#add make:view command at cli
https://github.com/svenluijten/artisan-view

#add default gravater in user table
https://github.com/danrovito/Laravel-Gravatar

#export excel
https://github.com/Maatwebsite/Laravel-Excel

#barcode/qr code generator
https://github.com/milon/barcode

#database backup for 5.5 or less
https://github.com/spatie/laravel-backup

#convert normal sql to eloquent
http://www.midnightcowboycoder.com/

#tons of package by spatie
https://spatie.be/en/opensource/laravel